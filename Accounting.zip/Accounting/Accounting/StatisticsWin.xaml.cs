﻿using Accounting.DB;
using Accounting.Models;
using Microsoft.EntityFrameworkCore;
using Spire.Xls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Wpf.Ui.Controls;
using Card = Accounting.Models.Card;
using MessageBox = System.Windows.MessageBox;

namespace Accounting
{
    /// <summary>
    /// Логика взаимодействия для StatisticsWin.xaml
    /// </summary>
    public partial class StatisticsWin : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        void Signal([CallerMemberName] string prop = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }

        private Card selectedCard;
        private List<Finance> finances;
        private List<Budget> budgets;
        private Budget budget;
        private decimal allExpensesToday;
        private List<Finance> dayExpenses;
        private List<Finance> monthExpenses;
        private decimal allExpensesMonth;
        private List<Finance> yearExpenses;
        private decimal allExpensesYear;
        private List<Finance> expenses;
        private decimal allExpenses;
        private List<Finance> dayIncome;
        private List<Finance> monthIncome;
        private List<Finance> yearIncome;
        private List<Finance> income;
        private decimal allIncomeToday;
        private decimal allIncomeMonth;
        private decimal allIncomeYear;
        private decimal allIncome;
        private List<IncomeOrExpense> incomeOrExpenses;
        private IncomeOrExpense selectedIncomeOrExpense;

        public User User { get; set; }
        public List<Finance> Finances
        {
            get => finances;
            set
            {
                finances = value;
                Signal();
            }
        }
        public List<Budget> Budgets
        {
            get => budgets;
            set
            {
                budgets = value;
                Signal();
            }
        }

        public Budget Budget
        {
            get => budget;
            set
            {
                budget = value;
                Signal();
            }
        }

        public List<Finance> DayExpenses
        {
            get => dayExpenses;
            set
            {
                dayExpenses = value;
                Signal();
            }
        }
        public List<Finance> MonthExpenses
        {
            get => monthExpenses;
            set
            {
                monthExpenses = value;
                Signal();
            }
        }
        public List<Finance> YearExpenses
        {
            get => yearExpenses;
            set
            {
                yearExpenses = value;
                Signal();
            }
        }
        public List<Finance> Expenses
        {
            get => expenses;
            set
            {
                expenses = value;
                Signal();
            }
        }
        public Decimal AllExpensesToday
        {
            get => allExpensesToday;
            set
            {
                allExpensesToday = value;
                Signal();
            }
        }
        public Decimal AllExpensesMonth
        {
            get => allExpensesMonth;
            set
            {
                allExpensesMonth = value;
                Signal();
            }
        }
        public Decimal AllExpensesYear
        {
            get => allExpensesYear;
            set
            {
                allExpensesYear = value;
                Signal();
            }
        }
        public Decimal AllExpenses
        {
            get => allExpenses;
            set
            {
                allExpenses = value;
                Signal();
            }
        }

        public List<Finance> DayIncome
        {
            get => dayIncome;
            set
            {
                dayIncome = value;
                Signal();
            }
        }
        public List<Finance> MonthIncome
        {
            get => monthIncome;
            set
            {
                monthIncome = value;
                Signal();
            }
        }
        public List<Finance> YearIncome
        {
            get => yearIncome;
            set
            {
                yearIncome = value;
                Signal();
            }
        }
        public List<Finance> Income
        {
            get => income;
            set
            {
                income = value;
                Signal();
            }
        }
        public Decimal AllIncomeToday
        {
            get => allIncomeToday;
            set
            {
                allIncomeToday = value;
                Signal();
            }
        }
        public Decimal AllIncomeMonth
        {
            get => allIncomeMonth;
            set
            {
                allIncomeMonth = value;
                Signal();
            }
        }
        public Decimal AllIncomeYear
        {
            get => allIncomeYear;
            set
            {
                allIncomeYear = value;
                Signal();
            }
        }
        public Decimal AllIncome
        {
            get => allIncome;
            set
            {
                allIncome = value;
                Signal();
            }
        }

        public List<Card> Cards { get; set; }
        public Card Card { get; set; }
        public Card SelectedCard
        {
            get => selectedCard;
            set
            {
                selectedCard = value;
                Filtr();
            }
        }

        public List<IncomeOrExpense> IncomeOrExpenses
        {
            get => incomeOrExpenses;
            set
            {
                incomeOrExpenses = value;
                Signal();
            }
        }
        public IncomeOrExpense SelectedIncomeOrExpense 
        {
            get => selectedIncomeOrExpense;
            set
            {
                selectedIncomeOrExpense = value;
                Filtr();
            }
        }

        public StatisticsWin(Models.User user)
        {
            InitializeComponent();
            DataContext = this;
            User = user;
            try
            {
                Card = accountingContext.Instance().Cards.FirstOrDefault(s => s.IdUser == user.Id);
                SelectedCard = Card;

                IncomeOrExpenses = new List<IncomeOrExpense> { new IncomeOrExpense { Id = 0, Name = "Все" } };
                IncomeOrExpenses.AddRange(accountingContext.Instance().IncomeOrExpenses);
                SelectedIncomeOrExpense = IncomeOrExpenses[0];

                Cards = accountingContext.Instance().Cards.Where(s => s.IdUser == user.Id).ToList();
                Budgets = accountingContext.Instance().Budgets.Where(s => s.IdCard == SelectedCard.Id).ToList();
            }
            catch
            {
                MessageBox.Show("Ошибка связи с БД");
            }
        }
        private void Filtr()
        {
            AllExpensesToday = 0;
            Signal(nameof(AllExpensesToday));
            AllExpensesMonth = 0;
            Signal(nameof(AllExpensesMonth));
            AllExpensesYear = 0;
            Signal(nameof(AllExpensesYear));
            AllExpenses = 0;
            Signal(nameof(AllExpenses));

            AllIncomeToday = 0;
            Signal(nameof(AllIncomeToday));
            AllIncomeMonth = 0;
            Signal(nameof(AllIncomeMonth));
            AllIncomeYear = 0;
            Signal(nameof(AllIncomeYear));
            AllIncome = 0;
            Signal(nameof(AllIncome));

            


            IQueryable<Finance> filtr = accountingContext.Instance().Finances;

            if (SelectedCard != null)
                filtr = filtr.Where(s => s.IdCard == SelectedCard.Id);
            Finances = new List<Finance>(filtr);

            IQueryable<Finance> filtrIE = accountingContext.Instance().Finances;

            if (SelectedIncomeOrExpense != null)
                filtrIE = filtrIE.Where(s => s.IdCard == SelectedCard.Id && s.IdIncomeOrExpenses == SelectedIncomeOrExpense.Id || s.IdCard == SelectedCard.Id && SelectedIncomeOrExpense.Id == 0);
            Finances = new List<Finance>(filtrIE);

            IQueryable<Budget> filtrB = accountingContext.Instance().Budgets;

            if (SelectedCard != null)
                filtrB = filtrB.Where(s => s.IdCard == SelectedCard.Id);
            Budgets = new List<Budget>(filtrB);
            Budget = Budgets.FirstOrDefault();

            IQueryable<Finance> filtrET = accountingContext.Instance().Finances;

            if (SelectedCard != null)
                filtrET = filtrET.Where(s => s.IdCard == SelectedCard.Id && s.IdIncomeOrExpenses == 2 && s.Date.Day == DateTime.Now.Day && s.Date.Month == DateTime.Now.Month && s.Date.Year == DateTime.Now.Year);
            DayExpenses = new List<Finance>(filtrET);
            AllExpToday();

            IQueryable<Finance> filtrEM = accountingContext.Instance().Finances;

            if (SelectedCard != null)
                filtrEM = filtrEM.Where(s => s.IdCard == SelectedCard.Id && s.IdIncomeOrExpenses == 2 && s.Date.Month == DateTime.Now.Month && s.Date.Year == DateTime.Now.Year);
            MonthExpenses = new List<Finance>(filtrEM);
            AllExpMonth();

            IQueryable<Finance> filtrEY = accountingContext.Instance().Finances;

            if (SelectedCard != null)
                filtrEY = filtrEY.Where(s => s.IdCard == SelectedCard.Id && s.IdIncomeOrExpenses == 2 && s.Date.Year == DateTime.Now.Year);
            YearExpenses = new List<Finance>(filtrEY);
            AllExpYear();

            IQueryable<Finance> filtrE = accountingContext.Instance().Finances;

            if (SelectedCard != null)
                filtrE = filtrE.Where(s => s.IdCard == SelectedCard.Id && s.IdIncomeOrExpenses == 2);
            Expenses = new List<Finance>(filtrE);
            Expense();

            IQueryable<Finance> filtrIT = accountingContext.Instance().Finances;

            if (SelectedCard != null)
                filtrIT = filtrIT.Where(s => s.IdCard == SelectedCard.Id && s.IdIncomeOrExpenses == 1 && s.Date.Day == DateTime.Now.Day && s.Date.Month == DateTime.Now.Month && s.Date.Year == DateTime.Now.Year);
            DayIncome = new List<Finance>(filtrIT);
            IncomeToday();

            IQueryable<Finance> filtrIM = accountingContext.Instance().Finances;

            if (SelectedCard != null)
                filtrIM = filtrIM.Where(s => s.IdCard == SelectedCard.Id && s.IdIncomeOrExpenses == 1 && s.Date.Month == DateTime.Now.Month && s.Date.Year == DateTime.Now.Year);
            MonthIncome = new List<Finance>(filtrIM);
            IncomeMonth();

            IQueryable<Finance> filtrIY = accountingContext.Instance().Finances;

            if (SelectedCard != null)
                filtrIY = filtrIY.Where(s => s.IdCard == SelectedCard.Id && s.IdIncomeOrExpenses == 1 && s.Date.Year == DateTime.Now.Year);
            YearIncome = new List<Finance>(filtrIY);
            IncomeYear();

            IQueryable<Finance> filtrI = accountingContext.Instance().Finances;

            if (SelectedCard != null)
                filtrI = filtrI.Where(s => s.IdCard == SelectedCard.Id && s.IdIncomeOrExpenses == 1);
            Income = new List<Finance>(filtrI);
            IncomeAll();
        }
        //Методы считающие траты
        private void AllExpToday()
        {
            foreach (var num in DayExpenses)
            {
                AllExpensesToday += num.Sum;
            }
        }

        private void AllExpMonth()
        {
            foreach (var num in MonthExpenses)
            {
                AllExpensesMonth += num.Sum;
            }
        }

        private void AllExpYear()
        {
            foreach (var num in YearExpenses)
            {
                AllExpensesYear += num.Sum;
            }
        }

        private void Expense()
        {
            foreach (var num in Expenses)
            {
                AllExpenses += num.Sum;
            }
        }

        //Методы считающие доходы
        private void IncomeToday()
        {
            foreach (var num in DayIncome)
            {
                AllIncomeToday += num.Sum;
            }
        }

        private void IncomeMonth()
        {
            foreach (var num in MonthIncome)
            {
                AllIncomeMonth += num.Sum;
            }
        }

        private void IncomeYear()
        {
            foreach (var num in YearIncome)
            {
                AllIncomeYear += num.Sum;
            }
        }

        private void IncomeAll()
        {
            foreach (var num in Income)
            {
                AllIncome += num.Sum;
            }
        }

        private void ToExcel(object sender, RoutedEventArgs e)
        {
            try
            {
                Workbook book = new Workbook();
                Worksheet sheet = book.Worksheets[0];
                System.Data.DataTable table = new System.Data.DataTable();
                table.Columns.Add("Период");
                table.Columns.Add("Доходы", typeof(decimal));
                table.Columns.Add("Расходы", typeof(decimal));
                table.Rows.Add(DateTime.Now.ToString("dd/MM/yy"), AllIncomeToday, AllExpensesToday);
                table.Rows.Add(DateTime.Now.ToString("Y"), AllIncomeMonth, AllExpensesMonth);
                table.Rows.Add(DateTime.Now.Year, AllIncomeYear, AllExpensesYear);
                table.Rows.Add("Всё время", AllIncome, AllExpenses);
                sheet.Range["A1"].ColumnWidth = 20;
                sheet.Range["A7"].Value = "Баланс счёта";
                sheet.Range["B7"].Value = $"{Budget.Total}";

                //стиль
                sheet.Range["A1:C1"].Style.Font.IsBold = true;
                sheet.Range["A1:C1"].Style.KnownColor = ExcelColors.Yellow;
                sheet.Range["A1:C1"].Style.Font.Color = System.Drawing.Color.Black;
                sheet.Range["A1:C7"].Style.HorizontalAlignment = HorizontalAlignType.Center;
                sheet.Range["A1:C7"].Style.VerticalAlignment = VerticalAlignType.Center;
                sheet.Range["B2:C7"].Style.NumberFormat = "#,##0\"₽\"";


                sheet.InsertDataTable(table, true, 1, 1);

                string file = $"Отчёт {User.FIO} по счёту {SelectedCard.AccountNumber} за {DateTime.Now.ToString("dd/MM/yy")}.xls";
                book.SaveToFile(file, ExcelVersion.Version2016);
                ProcessStartInfo process = new ProcessStartInfo();
                process.FileName = "explorer.exe";
                process.Arguments = file;
                process.UseShellExecute = true;
                System.Diagnostics.Process.Start(process);
            }
            catch
            {
                MessageBox.Show("Ой, что-то пошло не так. Возможно вам стоит закрыть прошлый файл :)");
                return;
            }

        }
    }
}
