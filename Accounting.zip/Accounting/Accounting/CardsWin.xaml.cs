﻿using Accounting.DB;
using Accounting.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Accounting
{
    /// <summary>
    /// Логика взаимодействия для CardsWin.xaml
    /// </summary>
    public partial class CardsWin : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        void Signal([CallerMemberName] string prop = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
        private List<Card> cards;
        public User User { get; set; }
        public string NameC { get; set; }
        public string AccountNumber { get; set; }
        public decimal Total { get; set; }
        public Card Card { get; set; }

        public List<Finance> Finances { get; set; }
        public Budget Budget { get; set; }
        public List<AutoPayment> AutoPayments { get; set; }
        public List<Card> Cards 
        {
            get => cards;
            set
            {
                cards = value;
                Signal();
            }
        }
        public string MyLenght = "40800000000000000000";
        public Card SelectedCard { get; set; }
        public CardsWin(Models.User user)
        {
            InitializeComponent();
            DataContext = this;
            User = user;
            try
            {
                Cards = accountingContext.Instance().Cards.Include(s => s.Budgets).Where(s => s.IdUser == user.Id).ToList();
            }
            catch
            {
                MessageBox.Show("Ошибка связи с БД");
            }
        }
        private void AddCard(object sender, RoutedEventArgs e)
        {
            Regex regex = new Regex(@"^[0-9]+$"); //регулярка для цифр
            if (string.IsNullOrEmpty(NameC) || string.IsNullOrEmpty(AccountNumber) )
            {
                MessageBox.Show("Не все поля заполнены ил заполнены неверно");
                return;
            }
            else
            {
                if(AccountNumber.ToString().Length != MyLenght.ToString().Length || !regex.IsMatch(AccountNumber))
                {
                    MessageBox.Show("Номер платёжного счёта должен содержать 20 цифр");
                    return;
                }
                else
                {
                    try
                    {
                        var nameCard = accountingContext.Instance().Cards.FirstOrDefault(s => s.Name == NameC && s.IdUser == User.Id);
                        if (nameCard != null)
                        {
                            MessageBox.Show("Такое имя для счёта уже существует");
                            return;
                        }
                        {
                            var numberCard = accountingContext.Instance().Cards.FirstOrDefault(s => s.AccountNumber == AccountNumber);
                            if (numberCard != null)
                            {
                                MessageBox.Show("Номер такого счёта уже существует");
                                return;
                            }
                            else
                            {
                                Card = new Card() { AccountNumber = AccountNumber, Name = NameC, IdUser = User.Id };
                                accountingContext.Instance().Cards.Add(Card);
                                accountingContext.Instance().SaveChanges();
                                var lastCard = accountingContext.Instance().Cards.ToList().LastOrDefault();
                                if (Total != 0)
                                {
                                    Budget = new Budget() { IdUser = User.Id, IdCard = lastCard.Id, Total = Total };
                                    accountingContext.Instance().Budgets.Add(Budget);
                                    accountingContext.Instance().SaveChanges();
                                }
                            }
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Ошибка связи с БД");
                    }
                    
                }
            }
            try
            {
                Cards = accountingContext.Instance().Cards.Include(s => s.Budgets).Where(s => s.IdUser == User.Id).ToList();
            }
            catch
            {
                MessageBox.Show("Ошибка связи с БД");
            }
        }

        private void RemoveCard(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Если вы удалите счёт, то вместе с ним пропадут все транзакции и статистика. Продолжить?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    if (SelectedCard != null)
                    {
                        AutoPayments = accountingContext.Instance().AutoPayments.Where(s => s.IdCard == SelectedCard.Id).ToList();
                        if (AutoPayments != null)
                        {
                            foreach (var ap in AutoPayments)
                            {
                                accountingContext.Instance().AutoPayments.Remove(ap);
                                accountingContext.Instance().SaveChanges();
                            }
                        }

                        Budget = accountingContext.Instance().Budgets.FirstOrDefault(s => s.IdCard == SelectedCard.Id);
                        if (Budget != null)
                        {
                            accountingContext.Instance().Budgets.Remove(Budget);
                            accountingContext.Instance().SaveChanges();
                        }

                        Finances = accountingContext.Instance().Finances.Where(s => s.IdCard == SelectedCard.Id).ToList();
                        if (Finances != null)
                        {
                            foreach (var fin in Finances)
                            {
                                accountingContext.Instance().Finances.Remove(fin);
                                accountingContext.Instance().SaveChanges();
                            }
                        }

                        accountingContext.Instance().Cards.Remove(SelectedCard);
                        accountingContext.Instance().SaveChanges();

                    }
                    Cards = accountingContext.Instance().Cards.Include(s => s.Budgets).Where(s => s.IdUser == User.Id).ToList();
                }
                catch
                {
                    MessageBox.Show("Ошибка связи с БД");
                }
            }
            

        }

    }
}
