﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Accounting.Classes
{
    public class Hash
    {
        public static string HashPassword(string pass)
        {
            var bytes = Encoding.UTF8.GetBytes(pass);
            var hashBytes = SHA256.Create().ComputeHash(bytes);
            return Encoding.UTF8.GetString(hashBytes);
        }
    }
}
