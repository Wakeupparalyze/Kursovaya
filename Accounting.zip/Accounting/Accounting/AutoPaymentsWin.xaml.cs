﻿using Accounting.DB;
using Accounting.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Accounting
{
    /// <summary>
    /// Логика взаимодействия для AutoPaymentsWin.xaml
    /// </summary>
    public partial class AutoPaymentsWin : Window, INotifyPropertyChanged
    {
        private List<AutoPayment> autoPayments;
        private CategoryAutoPayment fSelectedCategoryAutoPayment;

        public event PropertyChangedEventHandler? PropertyChanged;
        void Signal([CallerMemberName] string prop = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
        public AutoPayment AutoPayment { get; set; }
        public List<AutoPayment> AutoPayments
        {
            get => autoPayments;
            set
            {
                autoPayments = value;
                Signal();
            }
        }
        public AutoPayment SelectedAutoPayment { get; set; }
        public string NameAP { get; set; }
        public List<CategoryAutoPayment> CategoryAutoPayments { get; set; }
        public List<CategoryAutoPayment> FCategoryAutoPayments { get; set; }
        public CategoryAutoPayment SelectedCategoryAutoPayment { get; set; }
        public CategoryAutoPayment FSelectedCategoryAutoPayment 
        { 
            get => fSelectedCategoryAutoPayment;
            set
            {
                fSelectedCategoryAutoPayment = value;
                Filtr();
            }
        }
        public DateTime Date { get; set; } = DateTime.Now;
        public decimal Sum { get; set; }
        public List<Card> Cards { get; set; }
        public Card SelectedCard { get; set; }
        public Card Card { get; set; }
        public User User { get; set; }
        public AutoPaymentsWin(Models.User user)
        {
            InitializeComponent();
            DataContext = this;
            User = user;
            try
            {
                Card = accountingContext.Instance().Cards.FirstOrDefault(s => s.IdUser == user.Id);
                AutoPayments = accountingContext.Instance().AutoPayments.Where(s => s.IdCardNavigation.IdUser == Card.IdUser).ToList();
                CategoryAutoPayments = accountingContext.Instance().CategoryAutoPayments.ToList();
                Cards = accountingContext.Instance().Cards.Where(s => s.IdUser == user.Id).ToList();

                FCategoryAutoPayments = new List<CategoryAutoPayment> { new CategoryAutoPayment { Id = 0, Name = "Все категории" } };
                FCategoryAutoPayments.AddRange(accountingContext.Instance().CategoryAutoPayments);
                FSelectedCategoryAutoPayment = FCategoryAutoPayments[0];
            }
            catch
            {
                MessageBox.Show("Ошибка связи с БД!");
            }
        }

        private void AddAutoPayment(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(NameAP) || SelectedCategoryAutoPayment == null || Sum == 0 || SelectedCard == null)
            {
                MessageBox.Show("Не все поля заполнены");
                return;
            }
            else
            {
                var findNameAP = accountingContext.Instance().AutoPayments.FirstOrDefault(s => s.Name == NameAP);
                if (findNameAP == null)
                {
                    try
                    {
                        AutoPayment = new AutoPayment() { Name = NameAP, IdCategoryAutoPayment = SelectedCategoryAutoPayment.Id, Date = Date, Sum = Sum, IdCard = SelectedCard.Id };
                        accountingContext.Instance().AutoPayments.Add(AutoPayment);
                        accountingContext.Instance().SaveChanges();
                        AutoPayments = new List<AutoPayment>(accountingContext.Instance().AutoPayments.Where(s => s.IdCardNavigation.IdUser == Card.IdUser).ToList());
                        MessageBox.Show("Успешно добавлено!");
                    }
                    catch
                    {
                        MessageBox.Show("Ошибка БД!");
                    }

                }
                else
                {
                    MessageBox.Show("Автоплатёж с таким названием уже существует", "Внимание");
                }
            }
        }

        private void RemoveAutoPayment(object sender, RoutedEventArgs e)
        {
            if (SelectedAutoPayment != null)
            {
                try
                {
                    accountingContext.Instance().AutoPayments.Remove(SelectedAutoPayment);
                    accountingContext.Instance().SaveChanges();
                    AutoPayments = accountingContext.Instance().AutoPayments.Where(s => s.IdCardNavigation.IdUser == Card.IdUser).ToList();
                    MessageBox.Show("Успешно удалено!");
                }
                catch
                {
                    MessageBox.Show("Ошибка БД!");
                }
            }
        }

        private void Filtr()
        {
            IQueryable<AutoPayment> filtr = accountingContext.Instance().AutoPayments;

            if (FSelectedCategoryAutoPayment != null)
                filtr = filtr.Where(s => s.IdCategoryAutoPayment == FSelectedCategoryAutoPayment.Id && s.IdCardNavigation.IdUser == Card.IdUser || FSelectedCategoryAutoPayment.Id == 0 && s.IdCardNavigation.IdUser == Card.IdUser);
            AutoPayments = new List<AutoPayment>(filtr);
        }
    }
}
