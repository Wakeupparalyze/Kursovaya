﻿using System;
using System.Collections.Generic;

namespace Accounting.Models
{
    public partial class AutoPayment
    {
        public AutoPayment()
        {
            Finances = new HashSet<Finance>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public int IdCategoryAutoPayment { get; set; }
        public DateTime Date { get; set; }
        public decimal Sum { get; set; }
        public int IdCard { get; set; }

        public virtual Card IdCardNavigation { get; set; } = null!;
        public virtual CategoryAutoPayment IdCategoryAutoPaymentNavigation { get; set; } = null!;
        public virtual ICollection<Finance> Finances { get; set; }
    }
}
