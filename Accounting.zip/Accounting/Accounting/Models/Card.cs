﻿using System;
using System.Collections.Generic;

namespace Accounting.Models
{
    public partial class Card
    {
        public Card()
        {
            AutoPayments = new HashSet<AutoPayment>();
            Budgets = new HashSet<Budget>();
            Finances = new HashSet<Finance>();
        }

        public int Id { get; set; }
        public string AccountNumber { get; set; } = null!;
        public string Name { get; set; } = null!;
        public int IdUser { get; set; }

        public virtual User IdUserNavigation { get; set; } = null!;
        public virtual ICollection<AutoPayment> AutoPayments { get; set; }
        public virtual ICollection<Budget> Budgets { get; set; }
        public virtual ICollection<Finance> Finances { get; set; }
    }
}
