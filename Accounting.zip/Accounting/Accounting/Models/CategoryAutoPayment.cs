﻿using System;
using System.Collections.Generic;

namespace Accounting.Models
{
    public partial class CategoryAutoPayment
    {
        public CategoryAutoPayment()
        {
            AutoPayments = new HashSet<AutoPayment>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;

        public virtual ICollection<AutoPayment> AutoPayments { get; set; }
    }
}
